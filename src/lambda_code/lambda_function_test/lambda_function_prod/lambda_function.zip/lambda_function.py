import boto3
import os



def lambda_handler():
    return "Hello from Lambda! We are in production now!"